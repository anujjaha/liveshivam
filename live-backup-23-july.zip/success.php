<?php
	require_once ("lib/master.class.php");
	require_once ("menu.php");
?>
<?php
if($_REQUEST['msg'] == 200 )
{
	echo "<center><h2>Data Saved Succesfully </h2></center>";
}
?>