<?php
	require_once ("lib/master.class.php");
	require_once ("menu.php");
?>
<table align="center" border="2" width="80%">
	<tr>	
    	<td width="50%" align="center">
        	<a href="class_chart.php">
            	School -> Class -> Chart
            </a>
        </td>
    	<td width="50%" align="center">
        	<a href="school_chart.php">
            	School -> Chart
            </a>
        </td>
    </tr>
</table>