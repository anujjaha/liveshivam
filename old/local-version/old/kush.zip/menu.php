<?php
if($_SESSION['login'] != true) {
			header("location:index.php");
		}
?>
<table  align="center" border="2">
	<tr>
    	<td class="menu">
        	<a href="home.php">
            	Home
            </a>
        </td>
        <td>
        	&nbsp; || &nbsp;
        </td>
        <td class="menu">
        	<a href="school_list.php">
            	School List
            </a>
        </td>
        <td>
        	&nbsp; || &nbsp;
        </td>
        <td class="menu">
        	<a href="add_students.php">
            	Create Student List
            </a>
        </td>
        <td>
        	&nbsp; || &nbsp;
        </td>
         <td class="menu">
        	<a href="size_chart.php">
            	Size Chart
            </a>
        </td>
        <td>
        	&nbsp; || &nbsp;
        </td>
        <td class="menu">
        	<a href="student_list.php">
            	Student List
            </a>
        </td>
        
        <td>
        	&nbsp; || &nbsp;
        </td>
        <td class="menu">
        	<a href="print_list.php">
            	Print List
            </a>
        </td>
        
        <td>
        	&nbsp; || &nbsp;
        </td>
        <td class="menu">
        	<a href="logout.php">
            	Log Out
            </a>
        </td>
    </tr>
</table>