<table align="center" border="2">
<form action="ck.php" method="post">
	<?php
	if(!empty($_REQUEST['status'])) {
	?>
    	<tr>
        	<td colspan="2" align="center">
            	User name Password Unvalid
            </td>
        </tr>
    <?php
	}
	?>
	<tr>
    	<td align="right">
        	Enter User Name : 
        </td>
        <td>
        	<input type="text" name="username" />
        </td>
    </tr>
	<tr>
    	<td align="right">
        	Enter Password : 
        </td>
        <td>
        	<input type="password" name="password" />
        </td>
    </tr>
    <tr>
    	<td colspan="2" align="center">
        	<input type="submit" name="Login" value="Login" />
            <input type="reset" name="Reset" value="Reset" />
        </td>
    </tr>
</table>