<?php
	session_start();
	unset($_SESSION['login']);
	unset($_SESSION['username']);
	session_destroy();
?>
<center>
<h1>
	Succesfully Log Out
</h1>
	<a href="index.php">
    	Login Again
    </a>
</center>