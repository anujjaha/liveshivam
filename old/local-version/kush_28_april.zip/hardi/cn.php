<?php
/*$con = mysql_connect("localhost","root","");

mysql_select_db("test",$con);*/
$con = mysql_connect("localhost","publishi_kush","kush@123");
		mysql_select_db("publishi_kush",$con);	
?>