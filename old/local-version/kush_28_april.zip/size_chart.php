<?php
	require_once ("lib/master.class.php");
	require_once ("menu.php");
?>
<table align="center" border="2" width="80%">
	<tr>	
    	<td width="50%" align="center">
        	<a href="school_chart.php">
            	<h2>
                Generate Chart
                </h2>
            </a>
        </td>
    </tr>
</table>