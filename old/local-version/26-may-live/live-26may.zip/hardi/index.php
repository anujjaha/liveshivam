<table align="center" border="2">
<form action="save.php" method="post">
	<tr>
    	<td>
        	1.
        </td>	
    	<td >
        	Name : 
        </td>
        <Td>
        	<input type="text" name="name" />
        </Td>
    </tr>
    
    <tr>
        <td>
        	2.
        </td>
    	<td >
        	Designation : 
        </td>
        <Td>
        	<input type="text" name="designation" />
        </Td>
    </tr>
    
    <tr>
    	<td>
        	3.
        </td>
    	<td >
        	Gender : 
        </td>
        <Td>
        	<label><input type="radio" checked  name="gender" value="Male" />Male </label>
            <label><input type="radio"  name="gender"  value="Female"/>Female </label>
        </Td>
    </tr>
    
     <tr>
     	<td>
        	4.
        </td>
    	<td >
        	Age Gropu : 
        </td>
        <Td>
        	<label><input type="radio"  name="agrp" value="u30" />Under 30</label>
            <label><input type="radio"  name="agrp" value="31to40" />31 to 40 Years</label>
             <label><input type="radio"  name="agrp" value="40plus" />Over 40 Years</label>
              <label><input type="radio" checked name="agrp" value="40plus" />None</label>
        </Td>
    </tr>
    
    <tr>
    	<td>
        	5.
        </td>
    	<td >
        	Maritial Status : 
        </td>
        <Td>
        	<label><input type="radio"  name="mstatus" value="married" />Married</label>
            <label><input type="radio"  name="mstatus"  value="unmarried"/>Un Married</label>
             <label><input type="radio" checked="checked"  name="mstatus"  value="No Info"/>No Information</label>
        </Td>
    </tr>
    
     <tr>
     <td>
        	6.
        </td>
    	<td >
        	Is your spouse employed ?: 
        </td>
        <Td>
        	<label><input type="radio"  name="semployed" value="yes" />Yes</label>
            <label><input type="radio"  name="semployed"  value="no"/>NO</label>
            <label><input type="radio" checked="checked" name="semployed"  value="none"/>None</label>
        </Td>
    </tr>
    
     <tr>
     <td>
        	7.
        </td>
    	<td >
        	You have any Children ? 
        </td>
        <Td>
        	<label><input type="radio"  name="child" value="yes" />Yes</label>
            <label><input type="radio"  name="child"  value="no"/>NO</label>
              <label><input type="radio" checked="checked"  name="child"  value="hide info"/>Hide Information</label>
        </Td>
    </tr>
    
     <tr>
       <td>
        	8.
        </td>
    	<td >
        	How many Child ? 
        </td>
        <Td>
        	<label><input type="radio"  name="childnum" value="1" />1</label>
            <label><input type="radio"  name="childnum"  value="2"/>2</label>
             <label><input type="radio"  name="childnum"  value="3"/>3</label>
              <label><input type="radio"  name="childnum"  value="more than 3"/>More than 3</label>
              <label><input type="radio" checked="checked"  name="childnum"  value="none"/>Hide Information </label>
        </Td>
    </tr>
    
    <tr>
    	 <td>
        	9.
        </td>
    	<td >
        	Age Group of your children ? 
        </td>
        <Td>
         	<label><input type="radio"  name="cage" value="under 2" />Under 2 year</label>
            <label><input type="radio"  name="cage"  value="2 - 5 years"/>2 - 5 Years</label>
             <label><input type="radio"  name="cage"  value="6-10 year"/>6 - 10 years</label>
              <label><input type="radio"  name="cage"  value="11-14 year"/>>11-14 years </label>
              <label><input type="radio"  name="cage"  value="15-18 year"/>15-18years </label>
              <label><input type="radio" checked="checked"  name="none"  value="none"/>Hide Information</label>
        </Td>
    </tr>
    
     <tr>
     	 <td>
        	10.
        </td>
    	<td >
        	Being an employed man/woman who is helping you to take care of your children?
        </td>
        <Td>
         	<label><input type="radio"  name="ccare" value="Spouce" />Spouce</label>
            <label><input type="radio"  name="ccare"  value="IN Law"/>IN Laws</label>
             <label><input type="radio"  name="ccare"  value="Parents"/>Parents</label>
              <label><input type="radio"  name="ccare"  value="servants"/>Servants</label>
              <label><input type="radio"  name="ccare"  value="day care center"/>Day care Center </label>
               <label><input type="radio"  name="ccare"  value="Not applicable"/>Not applicable</label>
               <label><input type="radio" checked="checked"  name="ccare"  value="None"/>No Information</label>
        </Td>
    </tr>
    
    <tr>
     <td>
        	11.
        </td>
    	<td >
        	How many days you work in week ?
        </td>
        <Td>
         	<label><input type="radio"  name="dweek" value="less than 5" />Less than 5</label>
            <label><input type="radio"  name="dweek"  value="5 Days"/>5 days</label>
             <label><input type="radio"  name="dweek"  value="6 Days"/>6 Days</label>
              <label><input type="radio"  name="dweek"  value="7 Days"/>7 Days</label>
               <label><input type="radio"  checked="checked" name="dweek"  value="None"/>Hide Information</label>
        </Td>
    </tr>
    
     <tr>
      <td>
        	12.
        </td>
    	<td >
        	How many hours you work in Day ?
        </td>
        <Td>
         	<label><input type="radio"  name="hday" value="7-8 hours" /> 7-8 Hours</label>
            <label><input type="radio"  name="hday"  value="8-9 Hours"/>8-9 Hours</label>
             <label><input type="radio"  name="hday"  value="9-10 Hours"/>9-10 Hours</label>
              <label><input type="radio"  name="hday"  value="10 - 12 hours"/>10-12 Hours</label>
              <label><input type="radio" checked="checked"  name="hday"  value="none"/>Hide Information</label>
        </Td>
    </tr>
    
     <tr>
      <td>
        	13.
        </td>
    	<td >
        	Specify the time in a day you spend in travelling to your work place.
        </td>
        <Td>
         	<label><input type="radio"  name="spend" value="less hour" />Less than Hour</label>
            <label><input type="radio"  name="spend"  value="Nearly one hour"/>Nearly One hour</label>
             <label><input type="radio"  name="spend"  value="Nearly two hour"/>Nearly two hour</label>
              <label><input type="radio"  name="spend"  value="More than two Hours"/>More than two hours</label>
              <label><input type="radio" checked="checked"  name="spend"  value="none"/>Hide Information</label>
        </Td>
    </tr>
    
    <tr>
    <td>
        	14.
        </td>
    	<td >
        	Do you work in Shifts ?
        </td>
        <Td>
         	<label><input type="radio"  name="shift" value="GeneralShift" />General Shift</label>
            <label><input type="radio"  name="shift"  value="Night Shift"/>Night Shift</label>
            <label><input type="radio"  name="shift"  value="Alternative"/>Alternative</label>
            <label><input type="radio" checked="checked"  name="shift"  value="None"/>Hide Information</label>
        </Td>
    </tr>
    
    <tr>
    <td>
        	15.
        </td>
    	<td >
        	Can you openly discuss issues related to your superior?
        </td>
        <Td>
         	<label><input type="radio"  name="superior" value="All time" />All Time</label>
            <label><input type="radio"  name="superior"  value="Some time"/>Some Time</label>
            <label><input type="radio"  name="superior"  value="Not at All"/>Not at all </label>
            <label><input type="radio" checked="checked"  name="superior"  value="None"/>Hide Information</label>
        </Td>
    </tr>
    
    <tr>
    <td>
        	16.
        </td>
    	<td >
        		Please tick the following services, which you have used?
        </td>
        <Td>
         	<label><input type="radio"  name="qualitytime" value="Never" />Never</label>
            <label><input type="radio"  name="qualitytime"  value="Rarely"/>Rarely</label>
            <label><input type="radio"  name="qualitytime"  value="Sometimes"/>Sometimes</label>
             <label><input type="radio"  name="qualitytime"  value="Often"/>Often</label>
              <label><input type="radio" checked="checked"  name="qualitytime"  value="none"/>Hide Information</label>
        </Td>
    </tr>
    
    <tr>
     <td>
        	17.
        </td>
    	<td >
        		Do you ever miss out any quality time with your family or your friends because of pressure of work?
        </td>
        <Td>
         	<label><input type="radio"  name="serviceuse" value="Medical Facilty" />Medical Faciltiy</label>
            <label><input type="radio"  name="serviceuse"  value="Education Allowance"/>Education Alowance</label>
            <label><input type="radio"  name="serviceuse"  value="Holiday per schem"/>Holiday Per scheme </label>
            <label><input type="radio" checked="checked"  name="serviceuse"  value="none"/>Hide Information </label>
        </Td>
    </tr>
    
    <tr>
    <td>
        	18.
        </td>
    	<td >
        		Do you feel stressed about the amount of time you spend at work?
        </td>
        <Td>
         	<label><input type="radio"  name="work" value="Neveer" />Never</label>
            <label><input type="radio"  name="work"  value="Rarely"/>Rarely</label>
            <label><input type="radio"  name="work"  value="Some time"/>Sometime</label>
            <label><input type="radio"  name="work"  value="Often"/>Often</label>
            <label><input type="radio"  name="work"  value="Always"/>Always</label>
              <label><input type="radio"  checked="checked" name="work"  value="none"/>Hide Information</label>
        </Td>
    </tr>
    
    <tr>
    	<td>
        	19.
        </td>
    	<td >
        			How do you manage stress arising from your work?
        </td>
        <Td>
         	<label><input type="radio"  name="mwork" value="Yoga" />Yoga</label>
            <label><input type="radio"  name="mwork"  value="Mediation"/>Meditation</label>
            <label><input type="radio"  name="mwork"  value="Entertainment"/>Entertainment</label>
            <label><input type="radio"  name="mwork"  value="Dance"/>Dance</label>
            <label><input type="radio"  name="mwork"  value="Music"/>Music</label>
             <label><input type="radio" checked="checked"  name="mwork"  value="none"/>None</label>
        </Td>
    </tr>
    
    <tr>
    <td>
        	20.
        </td>
    	<td >
        	Do you personally feel any of the following will help you to balance your work life?
        </td>
        <Td>
         	<label><input type="radio"  name="balance" value="Flexible Hours" />Flexible Hours</label>
            <label><input type="radio"  name="balance"  value="Holiday Paid off"/>Holiday Paid Time off</label>
            <label><input type="radio"  name="balance"  value="Job Sharing"/>Job Sharing</label>
            <label><input type="radio"  name="balance"  value="Tmie off Family"/>time off with Family</label>
            <label><input type="radio"  name="balance"  value="Music"/>Music</label>
            <label><input type="radio" checked="checked" name="balance"  value="none"/>None</label>
        </Td>
    </tr>	
    
    <tr>
     <td>
        	21.
        </td>
    	<td >
        			 Does your organization provide you with following additional work provisions?
        </td>
        <Td>
         	<label><input type="radio"  name="provisin" value="Telephone for personal use	" />Telephone for personal use	</label>
            <label><input type="radio"  name="provisin"  value="Counselling services for employees"/>Counselling services for employees</label>
            <label><input type="radio"  name="provisin"  value="Health programsParenting /family support program"/>Health programsParenting /family support program</label>
            <label><input type="radio"  name="provisin"  value="Exercise facilities"/>Exercise facilities</label>
            <label><input type="radio"  name="provisin"  value="Relocation facilities and choices"/>Relocation facilities and choices</label>
             <label><input type="radio"  name="provisin"  value="Transportation	"/>Transportation	</label>
              <label><input type="radio" checked="checked"  name="provisin"  value="none	"/>Hie Information	</label>
        </Td>
    </tr>
    
     <tr>
      <td>
        	22.
        </td>
    	<td >
         Do you think that if employees have good work-life balance the organization will be    more effective and successful?
        </td>
        <Td>
         	<label><input type="radio"  name="lifebal" value="Yes" />Yes</label>
            <label><input type="radio"  name="lifebal"  value="No"/>No</label>
           <label><input type="radio" checked="checked" name="lifebal"  value="None"/>None</label>
         </Td>
    </tr>
    
     <tr>
      <td>
        	22.
        </td>
    	<td >
       which of the following will be organisation’s benefits due to good work-life balance of the employees?
        </td>
        <Td>
         	<label><input type="radio"  name="orgnisation" value="Measured increase in productivity,commitment" />Measured increase in productivity,commitment</label>
            <label><input type="radio"  name="orgnisation"  value="Better teamwork and communication"/>Better teamwork and communication</label>
            <label><input type="radio"  name="orgnisation"  value="Improved morale"/>Improved morale</label>
            <label><input type="radio"  name="orgnisation"  value="Less negative organizational stress	"/>Less negative organizational stress	</label>
             <label><input type="radio" checked="checked" name="orgnisation"  value="None"/>Hide Information</label>
         </Td>
    </tr>
    
    <tr>
    	<td>
        	23.
        </td>
    	<td >
        		Suggestions
        </td>
        <Td>
         	<textarea name="mys" cols="40" rows="6"></textarea>
        </Td>
    </tr>
    <Tr>
    	<td colspan="3" align="center">
        	<input type="submit" name="save" value="Save" />
            <input type="reset" name="Reset" value="Reset" />
        </td>
    </Tr>
</table>