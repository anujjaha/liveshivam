<?php
	require_once ("lib/master.class.php");
	require_once ("menu.php");
?>
<center>
	<h1 class="home">
    	Welcome Home
    </h1>
	
	<a href="custom_invoice.php">
		Generate Custom Invoice
	</a>
	
	<br /><br /><br /><br /><br />
	<a href="cut_chart.php">
		Cutting Chart
	</a>

</center>